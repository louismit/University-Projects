module car_dealership {
	requires java.desktop;
}