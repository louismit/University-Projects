package main;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class admin extends staff{

	admin(String username, String password, String type_id) {
		super(username, password, type_id);
	}
	static void loadadminUI(){
		admin_window.main(null);
	}
	
	static void addUser(String username, String password, String role) {
		
		List<String> users = new ArrayList<String>();
			
		try {
			
			//gets details from text file
			 
			BufferedReader reader ;
			try {
				reader = new BufferedReader(new FileReader("cars-users.txt"));
				String line = reader.readLine();
				
				while (line != null) { //for each line append list
					users.add(line);
					line = reader.readLine();
				}
					
					reader.close();
					
			}catch(IOException e1) {
				e1.printStackTrace();
				JOptionPane.showMessageDialog(null, "Failed to load from file");
			}
			
			}catch(Exception e1){
				e1.printStackTrace();
				JOptionPane.showMessageDialog(null, "Failed to load from file");
			}
			
			////////////////////////////////////////////////////////
			
		try {
			PrintWriter stream = new PrintWriter("cars-users.txt");
			
			String encryptedPass = Encryption.encrypt(password);
			String newuser = username +", "+ encryptedPass+ ", " + role;
			
			for(int i = 0; i<users.size();i++) {
				stream.println(users.get(i));
			}
			
			stream.print(newuser);
						
			//////////////////////////////////////////////////
			stream.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
