package main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Window.Type;

public class login_window {
	
	
	static JFrame frmCarsLogin;
	private JPasswordField passwordField;
	private JTextField usernameField;
	public user User;
	public staff Staff;
	public admin Admin;
	public static List<Object> Vehicles = new ArrayList<Object>();
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login_window window = new login_window();
					window.frmCarsLogin.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public login_window() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCarsLogin = new JFrame();
		frmCarsLogin.setResizable(false);
		frmCarsLogin.setTitle("Cars Login");
		frmCarsLogin.setBounds(100, 100, 281, 142);
		frmCarsLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCarsLogin.getContentPane().setLayout(null);
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setBounds(20, 11, 82, 14);
		frmCarsLogin.getContentPane().add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(20, 36, 82, 14);
		frmCarsLogin.getContentPane().add(lblPassword);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(112, 33, 127, 20);
		frmCarsLogin.getContentPane().add(passwordField);
		
		usernameField = new JTextField();
		usernameField.setBounds(112, 8, 127, 20);
		frmCarsLogin.getContentPane().add(usernameField);
		usernameField.setColumns(10);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
				//gets details from form fields
				String username = usernameField.getText();
				String password = passwordField.getText();
				
				
				
				
				//handles whether a matching details are found
				boolean checkFound = false; 
				BufferedReader reader ;
				try {
					reader = new BufferedReader(new FileReader("cars-users.txt"));
					String line = reader.readLine();
					
					while (line != null) { //check if login credentials exist
						String strArray[] = line.split(", ");
						
						//encrypts/decrypts login information
						Encryption Encrypt =new Encryption();
						strArray[1] = Encrypt.encrypt(strArray[1]);
						
						if((username.contentEquals(strArray[0])) && (password.contentEquals( strArray[1]))){
							
							checkFound = true;
							
							//initialise object of correct user type if credentials match
							if (strArray[2].contentEquals("customer")) { 
								User = new user(strArray[0],strArray[1], strArray[2]);
								User.loaduserUI();//load customer screen
								frmCarsLogin.setVisible(false);
								
							}else if (strArray[2].contentEquals("staff")) {
								Staff = new staff(strArray[0],strArray[1], strArray[2]);
								Staff.loadstaffUI(); //change to staff view
								frmCarsLogin.setVisible(false);
								
							
								
							}else if (strArray[2].contentEquals("admin")) {
								Admin = new admin(strArray[0],strArray[1], strArray[2]);
								Admin.loadadminUI(); //change to admin view
								frmCarsLogin.setVisible(false);
							}
							
						}
						
						line = reader.readLine();
					}
					if(checkFound == false) {
						JOptionPane.showMessageDialog(null, "Incorrect username/password");
					}
					
					
					reader.close();
				}catch(IOException e1) {
					JOptionPane.showMessageDialog(null, "File Not Found");
				}
				
				}catch(Exception e1){
					JOptionPane.showMessageDialog(null, "File not found");
				}
			}
		});
		btnLogin.setBounds(133, 64, 89, 23);
		frmCarsLogin.getContentPane().add(btnLogin);
	}
}
