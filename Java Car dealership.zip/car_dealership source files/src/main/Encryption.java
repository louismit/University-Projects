package main;

public class Encryption {
	
	private static String password = "";
	
	public static String encrypt(String input) {
		
		char[] chars = input.toCharArray();
		if ((chars.length % 2) == 0) {
			for (var i = 0; i<chars.length ; i+=2) {
				char temp = chars[i];
				chars[i] = chars[i+1];
				chars[i+1] = temp;
				
			}
		}else if ((chars.length % 2) == 1) {
			for (var i = 0; i<chars.length - 1 ; i+=2) {
				char temp = chars[i];
				chars[i] = chars[i+1];
				chars[i+1] = temp;
				
			}
		}
		
		password = new String(chars);
		
		return password;
	}
}
