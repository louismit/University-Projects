package main;

import java.awt.EventQueue;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

public class admin_staff_window {
	

	static JFrame frmAdminStaffScreen;
	private JTextField textCalculate;
	private JTextField textSell;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
				try {
					admin_staff_window window = new admin_staff_window();
					admin_staff_window.frmAdminStaffScreen.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public admin_staff_window() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAdminStaffScreen = new JFrame();
		frmAdminStaffScreen.setTitle(" Staff Screen (Admin access)");
		frmAdminStaffScreen.setResizable(false);
		frmAdminStaffScreen.setBounds(100, 100, 529, 443);
		frmAdminStaffScreen.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAdminStaffScreen.getContentPane().setLayout(null);
		frmAdminStaffScreen.addWindowListener(new WindowAdapter() {
			// alters default closing action for handling of windows heirarchy
            @Override
            public void windowClosing(WindowEvent e) {
            	admin_window.frmAdminWindow.setVisible(true);
                frmAdminStaffScreen.dispose();
                
            }
        });
		
		
		
		JLabel lblAddCarsFrom = new JLabel("Add cars from");
		lblAddCarsFrom.setBounds(29, 321, 141, 14);
		frmAdminStaffScreen.getContentPane().add(lblAddCarsFrom);
		
		JLabel lblListOfAll = new JLabel("List of all vehicles");
		lblListOfAll.setBounds(48, 18, 172, 14);
		frmAdminStaffScreen.getContentPane().add(lblListOfAll);
		
		
		JLabel lblCarsimporttxt = new JLabel("cars-import.txt");
		lblCarsimporttxt.setBounds(29, 334, 118, 14);
		frmAdminStaffScreen.getContentPane().add(lblCarsimporttxt);
		
		JLabel lblAddNewCar = new JLabel("Add new car");
		lblAddNewCar.setBounds(219, 334, 81, 14);
		frmAdminStaffScreen.getContentPane().add(lblAddNewCar);
		
		textCalculate = new JTextField();
		textCalculate.setToolTipText("yyyy-mm-dd");
		textCalculate.setBounds(320, 232, 172, 20);
		frmAdminStaffScreen.getContentPane().add(textCalculate);
		textCalculate.setColumns(10);
		
		JButton btnSearch = new JButton("Open Search Window");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				admin_staff_search.main(null);
				frmAdminStaffScreen.setVisible(false);
			}
		});
		btnSearch.setBounds(320, 43, 172, 23);
		frmAdminStaffScreen.getContentPane().add(btnSearch);
		
		
		JLabel lblPrintAllCars = new JLabel("Print all cars to");
		lblPrintAllCars.setBounds(403, 321, 94, 14);
		frmAdminStaffScreen.getContentPane().add(lblPrintAllCars);
		
		JLabel lblCarsoutputtxt = new JLabel("cars-output.txt");
		lblCarsoutputtxt.setBounds(403, 334, 102, 14);
		frmAdminStaffScreen.getContentPane().add(lblCarsoutputtxt);
		
		
		
		JLabel lblCalculateRevenue = new JLabel("Calculate revenue");
		lblCalculateRevenue.setBounds(350, 207, 131, 14);
		frmAdminStaffScreen.getContentPane().add(lblCalculateRevenue);
		
		textSell = new JTextField();
		textSell.setToolTipText("yyyy-mm-dd or leave blank for current date");
		textSell.setBounds(320, 117, 172, 20);
		frmAdminStaffScreen.getContentPane().add(textSell);
		textSell.setColumns(10);
		
		JLabel lblSellVehicle = new JLabel("Sell vehicle");
		lblSellVehicle.setBounds(369, 94, 70, 14);
		frmAdminStaffScreen.getContentPane().add(lblSellVehicle);
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 50, 274, 236);
		frmAdminStaffScreen.getContentPane().add(scrollPane);
		
		
		JList listVehicles = new JList();
		scrollPane.setViewportView(listVehicles);
		listVehicles.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		JButton btnAddCars = new JButton("Add Cars");
		btnAddCars.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			//add cars objects from file
				try {
					admin.addcars();
					JOptionPane.showMessageDialog(null, "Success!");
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Failed to load from file");
				}
				
			}
		});
		btnAddCars.setBounds(28, 359, 89, 23);
		frmAdminStaffScreen.getContentPane().add(btnAddCars);
		
		
		
		JButton btnPrint = new JButton("Print");
		btnPrint.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					//outputs sorted cars to output.txt
					if (login_window.Vehicles.size() == 0) {
						JOptionPane.showMessageDialog(null, "No cars in system");
					}else {
					admin.printcars();
					JOptionPane.showMessageDialog(null, "Cars in system successfully written to cars-output.txt");
					}
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Failed to write to file");
				}
				
			}
		});
		btnPrint.setBounds(403, 359, 89, 23);
		frmAdminStaffScreen.getContentPane().add(btnPrint);
		
		JButton btnAddCar = new JButton("Add Car");
		btnAddCar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				admin_staff_add_car.main(null);
				frmAdminStaffScreen.setVisible(false);
			}
		});
		btnAddCar.setBounds(211, 359, 89, 23);
		frmAdminStaffScreen.getContentPane().add(btnAddCar);
		
		JButton btnCalculate = new JButton("Calculate");
		btnCalculate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//calculates revenue on a given day, if blank calculates revenue today
				if(textCalculate.getText().isEmpty()) {
					admin.calculaterevenue(LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE));
				}else {
					try {
						admin.calculaterevenue(textCalculate.getText());
					}catch(Exception e1) {
						
						JOptionPane.showMessageDialog(null, "Invalid date");
						
					}
				}
				
			}
		});
		btnCalculate.setBounds(361, 263, 89, 23);
		frmAdminStaffScreen.getContentPane().add(btnCalculate);
		
		JButton btnSell = new JButton("Sell");
		btnSell.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(listVehicles.getSelectedIndex() == -1) {
					JOptionPane.showMessageDialog(null, "No car selected");
				}else {
					int i = listVehicles.getSelectedIndex();
					car x = (car) login_window.Vehicles.get(i);
					if(x.selling_d.format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
						if(textSell.getText().isEmpty()) {
							admin.sellcar(i, LocalDate.now()); //sell at this date
							JOptionPane.showMessageDialog(null, "Succcessfully sold" );
						}else {
							try {
								admin.sellcar(i, LocalDate.parse(textSell.getText())); //sell at specified date
								JOptionPane.showMessageDialog(null, "Succcessfully sold" );
							}catch(Exception y) {
								JOptionPane.showMessageDialog(null, "Ivalid date format" );
							}
						}
					}else {
						JOptionPane.showMessageDialog(null, "Already sold" );
					}
				}
			}
		});
		btnSell.setBounds(361, 147, 89, 23);
		frmAdminStaffScreen.getContentPane().add(btnSell);
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//start of listbox display cars>>>>
				DefaultListModel model = new DefaultListModel();
				int count = 0;
				
				model.removeAllElements();
				
				for(Object i: login_window.Vehicles){
						String append = "";
					//format for accessing vehicles array
					if (!((car)i).car_type.contentEquals("Van")) {
						//appends list model to display for cars
							append = "license plate: "+ ((car)i).licence_plate + ", model: " + ((car)i).model+ ", type: " + ((car)i).car_type+", colour: " +((car)i).colour + ", mileage: " +
								((car)i).mileage+ ", accident history: " + ((car)i).accident_h
								+ ", transmission:  " + ((car)i).transmission+ ", price: " + ((car)i).price+ ", arrival date: " + 
								((car)i).arrival_d+ ", date sold: ";
						if ((((car)i).selling_d).format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
							append = append + "STILL AVAILABLE";
						}else {
							append = append + ((car)i).selling_d;
						}
						
						
						}
					 else{
						 //appends list model to display for vans
						 append = "license plate: "+ ((car)i).licence_plate + ", model: " + ((car)i).model+ ", type: " + ((car)i).car_type+
								 	", size: "+((van)i).size + ", colour: " +((car)i).colour+ ", mileage: " +
									((car)i).mileage+ ", accident history: " + ((car)i).accident_h
									+ ", transmission:  " + ((car)i).transmission+ ", price: " + ((car)i).price+ ", arrival date: " + 
									((car)i).arrival_d+ ", date sold: ";
							if ((((car)i).selling_d).format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
								append = append + "STILL AVAILABLE";
							}else {
								append = append + ((van)i).selling_d;
							}
							
							
							
						
					 }
				
				 model.add(count, append);
				 count++;
				}
				
				listVehicles.setModel(model);
				//end of listbox display cars>>>>
			}
		});
		btnRefresh.setBounds(211, 14, 89, 23);
		frmAdminStaffScreen.getContentPane().add(btnRefresh);
	}
}
