package main;

import java.time.LocalDate;
import java.util.Comparator;

public class car {
	
	public String licence_plate;
	public String model;
	public String car_type;
	public String colour;
	public int mileage;
	public String accident_h;
	public String transmission;
	public int price;
	public LocalDate arrival_d;
	public LocalDate selling_d;
	public int doors;
	public int seats;
	
	car(String lp , String mo, String ct, String c, String mi, String ah, String t, String p, String ad, String sd){
		licence_plate = lp;
		model = mo;
		car_type = ct;
		colour = c;
		mileage =Integer.parseInt(mi);
		accident_h = ah;
		transmission = t;
		price = Integer.parseInt(p);
		arrival_d = LocalDate.parse(ad);
		selling_d = LocalDate.parse(sd);
		
		switch(car_type){ //adds paramaters for seats and doors
		case "SUV":
			doors = 5;
			seats = 5;
			break;
		case "MPV":
			doors = 5;
			seats = 7;
			break;
		case "Van":
			doors = 5;
			seats = 3;
			break;
		case "Hatchback":
			doors = 5;
			seats = 4;
			break;
		case "Saloon":
			doors = 5;
			seats = 5;
			break;
		case "Coupe":
			doors = 2;
			seats = 2;
			break;
			
			
		}
		
				
		
		
	}

	
	
	

}
