package main;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class staff extends user{
	
	staff(String username, String password, String type_id) {
		super(username, password, type_id);
	}

	static void loadstaffUI(){ //loads staff type ui
		staff_window.main(null);
	}
	
	static void addcars() { //creates array of car and van type objects from cars-input.txt
		try {
			
			//gets details from text file
			 
			BufferedReader reader ;
			try {
				reader = new BufferedReader(new FileReader("cars-import.txt"));
				String line = reader.readLine();
				
				while (line != null) { //check if login credentials exist
					String currentvehicle[] = line.split(", ");
					
					if (currentvehicle[2].contentEquals("Van")) {
						
						if (currentvehicle.length == 11) {
							login_window.Vehicles.add(new van(currentvehicle[0],currentvehicle[1],currentvehicle[2],currentvehicle[3],currentvehicle[4],currentvehicle[5],currentvehicle[6],currentvehicle[7],currentvehicle[8],currentvehicle[9],currentvehicle[10]));
							
							} else if (currentvehicle.length == 10) {
								
								login_window.Vehicles.add(new van(currentvehicle[0],currentvehicle[1],currentvehicle[2],currentvehicle[3],currentvehicle[4],currentvehicle[5],currentvehicle[6],currentvehicle[7],currentvehicle[8],currentvehicle[9],"0000-01-01"));
								
							}else if (currentvehicle.length == 9) {
							// appends arrival date with current date
								login_window.Vehicles.add(new van(currentvehicle[0],currentvehicle[1],currentvehicle[2],currentvehicle[3],currentvehicle[4],currentvehicle[5],currentvehicle[6],currentvehicle[7],currentvehicle[8],LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE),"0000-01-01"));
								
							}
						
						
					} else {
						// cases for different input types from cars-imput.txt
						if (currentvehicle.length == 10) {
						login_window.Vehicles.add(new car(currentvehicle[0],currentvehicle[1],currentvehicle[2],currentvehicle[3],currentvehicle[4],currentvehicle[5],currentvehicle[6],currentvehicle[7],currentvehicle[8],currentvehicle[9]));
						
						} else if (currentvehicle.length == 9) {
							
							login_window.Vehicles.add(new car(currentvehicle[0],currentvehicle[1],currentvehicle[2],currentvehicle[3],currentvehicle[4],currentvehicle[5],currentvehicle[6],currentvehicle[7],currentvehicle[8],"0000-01-01"));
							
						}else if (currentvehicle.length == 8) {
						// appends arrival date with current date
							login_window.Vehicles.add(new car(currentvehicle[0],currentvehicle[1],currentvehicle[2],currentvehicle[3],currentvehicle[4],currentvehicle[5],currentvehicle[6],currentvehicle[7],LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE),"0000-01-01"));
							
						}
					}
					line = reader.readLine();
				}
					
					
				
				
				
				reader.close();
			}catch(IOException e1) {
				e1.printStackTrace();
				JOptionPane.showMessageDialog(null, "Failed to load from file");
			}
			
			}catch(Exception e1){
				e1.printStackTrace();
				JOptionPane.showMessageDialog(null, "Failed to load from file");
			}
		
	}
	
	static void addcar(String lp, String mo, String ct, String c, String mi, String ah, String t, String p, String ad) { // appends the array of car objects with a new car object using input parameters
		login_window.Vehicles.add(new car(lp, mo, ct, c, mi, ah, t, p, ad, "0000-01-01"));
	}
	
	static void addvan(String lp, String mo, String ct, String sz, String c, String mi, String ah, String t, String p, String ad) { // appends the array o car objects with a new van object
		login_window.Vehicles.add(new van(lp, mo, ct, sz, c, mi, ah, t, p, ad, "0000-01-01"));
		
	}
	
	static void sellcar(int index, LocalDate date) { //appends the selected car's selling date with either an input date or the current date 
		
		car x = (car) login_window.Vehicles.get(index);
		x.selling_d = date;
		login_window.Vehicles.set(index,x);
	}
	
	static void printcars() {//outputs all car objects in array to cars-output.txt
		String filename = "cars-output.txt";
		
		List<car> carlist = new ArrayList<car>();
		List<car> vanlist = new ArrayList<car>();
		
		//splits cars and vans into two separate lists
		for(Object i: login_window.Vehicles){
			if(((car)i).car_type.contentEquals("Van")){
				vanlist.add((van)i);
			}else
				carlist.add((car)i);
		}
		
		//conditions to sort cars by
		Comparator<car> arrivalComparitor = new Comparator<car>() {
            @Override
            public int compare(car o1, car o2) {
    			return o1.arrival_d.compareTo(o2.arrival_d);
            }
        };
        
        Comparator<car> SellingComparitor = new Comparator<car>() {
            @Override
            public int compare(car o1, car o2) {
    			return o1.selling_d.compareTo(o2.selling_d);
            }
        };
		
        Comparator<car> yetsoldComparitor = new Comparator<car>() {
            @Override
            public int compare(car o1, car o2) {
            	
    			if((o1.selling_d.format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) && (o1.selling_d.compareTo(o2.selling_d) < 0)) {
    				return 1;
    			}else if ((o2.selling_d.format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) && (o2.selling_d.compareTo(o1.selling_d) <0)){
    				return -1;
    			}else{
    				return 0;
    			}
            }
        };
		
        
        //sorts both arrays into correct output form and combines into one arraylist
		Collections.sort(carlist, arrivalComparitor);
		Collections.sort(vanlist, SellingComparitor);
		Collections.sort(vanlist, yetsoldComparitor);
		for(Object i: vanlist){
			carlist.add((car)i);	
		}
	
		//outputs carlist to file cars-output.txt
		try {
			PrintWriter stream = new PrintWriter(filename);
			
			////////////////////////////////////////////////////////
			
			for(Object i: carlist){
			
			//format for accessing vehicles array
			if (!((car)i).car_type.contentEquals("Van")) {
				//write line to file
					 stream.print(((car)i).licence_plate + ", " + ((car)i).model+ ", " + ((car)i).car_type+ ", " +((car)i).colour+", "+
						((car)i).mileage+ ", " + ((car)i).accident_h
						+ ", " + ((car)i).transmission+ ", " + ((car)i).price+ ", " + 
						((car)i).arrival_d);
						if ((((car)i).selling_d).format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
							 stream.println("");
						 }else {
							 stream.println(", "+((car)i).selling_d);
						 }
			
				
				
				
				}
			 else{
				 //writes line to file
				 stream.print(((car)i).licence_plate + ", " + ((car)i).model+ ", " + ((car)i).car_type+", " +((car)i).colour+ ", "+((van)i).size + ", "+
							((car)i).mileage+ ", " + ((car)i).accident_h
							+ ", " + ((car)i).transmission+ ", " + ((car)i).price+ ", " + 
							((car)i).arrival_d);
				 
				 if (((car)i).selling_d.format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
					 stream.println("");
				 }else {
					 stream.println(", "+((car)i).selling_d);
				 }
							
				
			 }
		}
		
			
			
			//////////////////////////////////////////////////
			stream.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	static void calculaterevenue(String moneydate) {//takes input date and sums the price of all cars sold on that date
		
		int moneymade = 0; //local variable for cumulative money on a specified date
		for(Object i: login_window.Vehicles){
			if(((car)i).selling_d.format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals(moneydate)){
				moneymade += ((car)i).price;
				
			}
		}
		
		if(moneymade == 0) {
			JOptionPane.showMessageDialog(null, "No money made on that date");
		}else {
			JOptionPane.showMessageDialog(null, "Money made: �"+moneymade);
		}
		
	}
}

