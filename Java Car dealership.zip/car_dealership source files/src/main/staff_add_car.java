package main;

import java.awt.EventQueue;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JTextField;

public class staff_add_car {

	private JFrame frmStaffAddCar;
	private JTextField txtc;
	private JTextField txtmo;
	private JTextField txtlp;
	private JTextField txtmi;
	private JTextField txta;
	private JTextField txtp;
	private JTextField txtad;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					staff_add_car window = new staff_add_car();
					window.frmStaffAddCar.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public staff_add_car() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmStaffAddCar = new JFrame();
		frmStaffAddCar.setTitle("Add New Car");
		frmStaffAddCar.setBounds(100, 100, 310, 394);
		frmStaffAddCar.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmStaffAddCar.getContentPane().setLayout(null);
		
		JLabel lblLicensePlate = new JLabel("License Plate");
		lblLicensePlate.setBounds(20, 29, 118, 14);
		frmStaffAddCar.getContentPane().add(lblLicensePlate);
		
		JLabel lblModel = new JLabel("Model");
		lblModel.setBounds(20, 54, 118, 14);
		frmStaffAddCar.getContentPane().add(lblModel);
		
		JLabel lblCarType = new JLabel("Car Type");
		lblCarType.setBounds(20, 79, 118, 14);
		frmStaffAddCar.getContentPane().add(lblCarType);
		
		JLabel lblColour = new JLabel("Colour");
		lblColour.setBounds(20, 104, 118, 14);
		frmStaffAddCar.getContentPane().add(lblColour);
		
		JLabel lblMileage = new JLabel("Mileage");
		lblMileage.setBounds(20, 129, 118, 14);
		frmStaffAddCar.getContentPane().add(lblMileage);
		
		JLabel lblAccidentHistory = new JLabel("Accident History");
		lblAccidentHistory.setBounds(20, 154, 118, 14);
		frmStaffAddCar.getContentPane().add(lblAccidentHistory);
		
		JLabel lblTransmission = new JLabel("Transmission");
		lblTransmission.setBounds(20, 179, 118, 14);
		frmStaffAddCar.getContentPane().add(lblTransmission);
		
		JComboBox comboBoxTr = new JComboBox();
		comboBoxTr.setModel(new DefaultComboBoxModel(new String[] {"automatic", "manual"}));
		comboBoxTr.setBounds(153, 175, 118, 22);
		frmStaffAddCar.getContentPane().add(comboBoxTr);
		
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setBounds(20, 204, 118, 14);
		frmStaffAddCar.getContentPane().add(lblPrice);
		
		JLabel lblArrival = new JLabel("Arrival Date");
		lblArrival.setBounds(20, 229, 118, 14);
		frmStaffAddCar.getContentPane().add(lblArrival);
		
		JButton btnAdd = new JButton("Add Car");
		
		JComboBox comboBoxType = new JComboBox();
		comboBoxType.setModel(new DefaultComboBoxModel(new String[] {"SUV", "MPV", "Van", "Hatchback", "Saloon", "Coupe"}));
		comboBoxType.setBounds(153, 75, 118, 22);
		frmStaffAddCar.getContentPane().add(comboBoxType);
		
		JComboBox comboBoxSize = new JComboBox();
		comboBoxSize.setModel(new DefaultComboBoxModel(new String[] {"small", "large"}));
		comboBoxSize.setBounds(153, 250, 118, 22);
		frmStaffAddCar.getContentPane().add(comboBoxSize);
		
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// assembles values to pass to addcar method in staff or admin class
				try {
					if (txtmo.getText().isEmpty() || txtlp.getText().isEmpty() || txtc.getText().isEmpty() || txtmi.getText().isEmpty() || txta.getText().isEmpty() || txtp.getText().isEmpty()) {
						//error if no values are entered
						JOptionPane.showMessageDialog(null, "No value specified in one or more fields");
						
					}else {
						//variables for fields in cars/vans
						String lp = txtlp.getText();
						String mo = txtmo.getText();
						String c = txtc.getText();
						String ct = (String)comboBoxType.getSelectedItem();
						String sz = (String)comboBoxSize.getSelectedItem();
						String mi = txtmi.getText();
						String a = txta.getText();
						String p = txtp.getText();
						String t = (String)comboBoxTr.getSelectedItem();
						String ad = txtad.getText();

						//validation for date and car/van type
						if (txtad.getText().isEmpty()) {
							ad = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
						}
						
						//select what type to add then call method to add it
						if(ct.contains("Van")) {
							staff.addvan(lp,mo,ct,sz,c,mi,a,t,p,ad);
							JOptionPane.showMessageDialog(null, "Van successfully added");
						}else {
							staff.addcar(lp,mo,ct,c,mi,a,t,p,ad);
							JOptionPane.showMessageDialog(null, "Car successfully added");
						}
						
						
					}
				}catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Please enter valid values (date must be in format YYYY-MM-DD)");
				}
			}
			
		});
		btnAdd.setBounds(93, 315, 89, 23);
		frmStaffAddCar.getContentPane().add(btnAdd);
		
		
		
		txtc = new JTextField();
		txtc.setBounds(148, 101, 123, 20);
		frmStaffAddCar.getContentPane().add(txtc);
		txtc.setColumns(10);
		
		txtmo = new JTextField();
		txtmo.setColumns(10);
		txtmo.setBounds(148, 51, 123, 20);
		frmStaffAddCar.getContentPane().add(txtmo);
		
		txtlp = new JTextField();
		txtlp.setColumns(10);
		txtlp.setBounds(148, 26, 123, 20);
		frmStaffAddCar.getContentPane().add(txtlp);
		
		txtmi = new JTextField();
		txtmi.setColumns(10);
		txtmi.setBounds(148, 126, 123, 20);
		frmStaffAddCar.getContentPane().add(txtmi);
		
		txta = new JTextField();
		txta.setColumns(10);
		txta.setBounds(148, 151, 123, 20);
		frmStaffAddCar.getContentPane().add(txta);
		
		txtp = new JTextField();
		txtp.setColumns(10);
		txtp.setBounds(148, 201, 123, 20);
		frmStaffAddCar.getContentPane().add(txtp);
		
		txtad = new JTextField();
		txtad.setColumns(10);
		txtad.setBounds(148, 226, 123, 20);
		frmStaffAddCar.getContentPane().add(txtad);
		
		JLabel lblSizevanOnly = new JLabel("Size (Van only)");
		lblSizevanOnly.setBounds(20, 254, 118, 14);
		frmStaffAddCar.getContentPane().add(lblSizevanOnly);
		
		
		
		frmStaffAddCar.addWindowListener(new WindowAdapter() {
			// alters default closing action for handling of windows heirarchy
            @Override
            public void windowClosing(WindowEvent e) {
            	staff_window.frmStaffScreen.setVisible(true);
                frmStaffAddCar.dispose();
                
            }
        });
	}
}
