package main;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class admin_window {

	public static JFrame frmAdminWindow;
	private JTextField textUsername;
	private JTextField textPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admin_window window = new admin_window();
					window.frmAdminWindow.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public admin_window() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAdminWindow = new JFrame();
		frmAdminWindow.setTitle("Admin Window");
		frmAdminWindow.setBounds(100, 100, 347, 252);
		frmAdminWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmAdminWindow.getContentPane().setLayout(null);
		frmAdminWindow.addWindowListener(new WindowAdapter() {
			// alters default closing action for handling of windows heirarchy
            @Override
            public void windowClosing(WindowEvent e) {
            	login_window.frmCarsLogin.setVisible(true);
                frmAdminWindow.dispose();
                
            }
        });
		
		textUsername = new JTextField();
		textUsername.setBounds(114, 24, 190, 20);
		frmAdminWindow.getContentPane().add(textUsername);
		textUsername.setColumns(10);
		
		textPassword = new JTextField();
		textPassword.setColumns(10);
		textPassword.setBounds(114, 55, 190, 20);
		frmAdminWindow.getContentPane().add(textPassword);
		
		JLabel lblNewLabel = new JLabel("Username:");
		lblNewLabel.setBounds(20, 27, 111, 14);
		frmAdminWindow.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Password:");
		lblNewLabel_1.setBounds(20, 58, 111, 14);
		frmAdminWindow.getContentPane().add(lblNewLabel_1);
		
		JComboBox comboBoxType = new JComboBox();
		comboBoxType.setModel(new DefaultComboBoxModel(new String[] {"customer", "staff", "admin"}));
		comboBoxType.setBounds(114, 90, 190, 22);
		frmAdminWindow.getContentPane().add(comboBoxType);
		
		JButton btnAddUser = new JButton("New User");
		btnAddUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(textUsername.getText().isEmpty()||textPassword.getText().isEmpty()) {
						JOptionPane.showMessageDialog(null, "Please enter a value for each field");
					}
					else {
						admin.addUser(textUsername.getText(),textPassword.getText(),(String)comboBoxType.getSelectedItem());
						JOptionPane.showMessageDialog(null, "User Created");
					}
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Please enter a value for each field");
				}
				
			}
		});
		btnAddUser.setBounds(20, 123, 284, 23);
		frmAdminWindow.getContentPane().add(btnAddUser);
		
		JButton btnStaffFunctions = new JButton("Staff Functions");
		btnStaffFunctions.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				admin_staff_window.main(null);	
				frmAdminWindow.setVisible(false);
			}
		});
		btnStaffFunctions.setBounds(20, 170, 284, 23);
		frmAdminWindow.getContentPane().add(btnStaffFunctions);
		
		
		
		JLabel lblRole = new JLabel("Role:");
		lblRole.setBounds(20, 94, 111, 14);
		frmAdminWindow.getContentPane().add(lblRole);
	}
}
