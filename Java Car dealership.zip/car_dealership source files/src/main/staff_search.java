package main;

import java.awt.EventQueue;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JOptionPane;

public class staff_search {

	private JFrame frmStaffSearch;
	private JTextField textModel;
	private JTextField textTransmission;
	private JTextField textColour;
	private JTextField textmin;
	private JTextField textmax;
	List<Object> searchVehiclelist = new ArrayList<Object>();
	search_access access = search_access.ALL; //allows staff access to accident history

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					staff_search window = new staff_search();
					window.frmStaffSearch.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public staff_search() {
		initialize();
		frmStaffSearch.addWindowListener(new WindowAdapter() {
			// alters default closing action for handling of windows heirarchy
            @Override
            public void windowClosing(WindowEvent e) {
            	staff_window.frmStaffScreen.setVisible(true);
                frmStaffSearch.dispose();
                
            }
        });
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		frmStaffSearch = new JFrame();
		frmStaffSearch.setTitle("Vehicle Search (Staff access)");
		frmStaffSearch.setBounds(100, 100, 940, 416);
		frmStaffSearch.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmStaffSearch.getContentPane().setLayout(null);
		
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(444, 21, 458, 329);
		frmStaffSearch.getContentPane().add(scrollPane);
		
		JList listSearch = new JList();
		scrollPane.setViewportView(listSearch);
		
		
		textModel = new JTextField();
		textModel.setBounds(56, 37, 96, 20);
		frmStaffSearch.getContentPane().add(textModel);
		textModel.setColumns(10);
		
		JLabel lblModel = new JLabel("Model:");
		lblModel.setBounds(83, 21, 48, 14);
		frmStaffSearch.getContentPane().add(lblModel);
		
		textTransmission = new JTextField();
		textTransmission.setColumns(10);
		textTransmission.setBounds(181, 37, 96, 20);
		frmStaffSearch.getContentPane().add(textTransmission);
		
		textColour = new JTextField();
		textColour.setColumns(10);
		textColour.setBounds(306, 37, 96, 20);
		frmStaffSearch.getContentPane().add(textColour);
		
		JLabel lblTransmission = new JLabel("Transmission:");
		lblTransmission.setBounds(189, 21, 129, 14);
		frmStaffSearch.getContentPane().add(lblTransmission);
		
		JLabel lblColour = new JLabel("Colour:");
		lblColour.setBounds(334, 21, 48, 14);
		frmStaffSearch.getContentPane().add(lblColour);
		
		textmin = new JTextField();
		textmin.setColumns(10);
		textmin.setBounds(56, 158, 96, 20);
		frmStaffSearch.getContentPane().add(textmin);
		
		textmax = new JTextField();
		textmax.setColumns(10);
		textmax.setBounds(306, 158, 96, 20);
		frmStaffSearch.getContentPane().add(textmax);
		
		JLabel lblMin = new JLabel("Min:");
		lblMin.setBounds(83, 143, 48, 14);
		frmStaffSearch.getContentPane().add(lblMin);
		
		JLabel lblMax = new JLabel("Max:");
		lblMax.setBounds(334, 143, 48, 14);
		frmStaffSearch.getContentPane().add(lblMax);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"small", "large"}));
		comboBox.setBounds(173, 279, 139, 22);
		frmStaffSearch.getContentPane().add(comboBox);
		
		JButton btnModel = new JButton("Search by model and transmission or colour");
		btnModel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				searchVehiclelist.clear();
				
				String carmodel = textModel.getText();
				String transmission = textTransmission.getText();
				String colour = textColour.getText();
				
				
				//add cars to searchlist that fulfils conditions
				if((carmodel.contentEquals("")||transmission.contentEquals(""))&&colour.contentEquals("")) {
					JOptionPane.showMessageDialog(null, "Enter (model and transmission together) or (colour)" );
				}else {
					for(Object i: login_window.Vehicles){
						if(((car)i).model.contentEquals(carmodel) && ((car)i).transmission.contentEquals(transmission)) {
							searchVehiclelist.add((car)i);
						}else if(((car)i).colour.contentEquals(colour)) {
							searchVehiclelist.add((car)i);
						}
					}
				}
				
				//start of listbox display cars>>>>
				DefaultListModel model = new DefaultListModel();
				int count = 0;
				
				model.removeAllElements();
				
				for(Object i: searchVehiclelist){
						String append = "";
					//format for accessing vehicles array
					if (!((car)i).car_type.contentEquals("Van")) {
						//appends list model to display for cars
							append = "license plate: "+ ((car)i).licence_plate + ", model: " + ((car)i).model+ ", type: " + ((car)i).car_type+", colour: " +((car)i).colour + ", mileage: " +
								((car)i).mileage+ ", accident history: " + ((car)i).accident_h
								+ ", transmission:  " + ((car)i).transmission+ ", price: " + ((car)i).price+ ", arrival date: " + 
								((car)i).arrival_d+ ", date sold: ";
						if ((((car)i).selling_d).format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
							append = append + "STILL AVAILABLE";
						}else {
							append = append + ((car)i).selling_d;
						}
						
						
						}
					 else{
						 //appends list model to display for vans
						 append = "license plate: "+ ((car)i).licence_plate + ", model: " + ((car)i).model+ ", type: " + ((car)i).car_type+
								 	", size: "+((van)i).size + ", colour: " +((car)i).colour+ ", mileage: " +
									((car)i).mileage+ ", accident history: " + ((car)i).accident_h
									+ ", transmission:  " + ((car)i).transmission+ ", price: " + ((car)i).price+ ", arrival date: " + 
									((car)i).arrival_d+ ", date sold: ";
							if ((((car)i).selling_d).format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
								append = append + "STILL AVAILABLE";
							}else {
								append = append + ((van)i).selling_d;
							}
							
							
							
						
					 }
				
				 model.add(count, append);
				 count++;
				}
				
				listSearch.setModel(model);
				//end of listbox display cars>>>>
				
			}
		});
		
		btnModel.setBounds(31, 68, 401, 23);
		frmStaffSearch.getContentPane().add(btnModel);
		
		JButton btnSearchBySeat = new JButton("Search by seat count");
		btnSearchBySeat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				searchVehiclelist.clear();
				
				int min;
				int max;
				try {
					min = Integer.valueOf(textmin.getText());
					max = Integer.valueOf(textmax.getText());
					for(Object i: login_window.Vehicles){
						if((((car)i).seats >= min) && (((car)i).seats <= max)) {
							searchVehiclelist.add((car)i);
						}
					}
				}catch(Exception e1) {
					JOptionPane.showMessageDialog(null, "Enter Valid Numbers" );
				}
				
				
				
				
				//start of listbox display cars>>>>
				DefaultListModel model = new DefaultListModel();
				int count = 0;
				
				model.removeAllElements();
				
				for(Object i: searchVehiclelist){
						String append = "";
					//format for accessing vehicles array
					if (!((car)i).car_type.contentEquals("Van")) {
						//appends list model to display for cars
							append = "license plate: "+ ((car)i).licence_plate + ", model: " + ((car)i).model+ ", type: " + ((car)i).car_type+", colour: " +((car)i).colour + ", mileage: " +
								((car)i).mileage+ ", accident history: " + ((car)i).accident_h
								+ ", transmission:  " + ((car)i).transmission+ ", price: " + ((car)i).price+ ", arrival date: " + 
								((car)i).arrival_d+ ", date sold: ";
						if ((((car)i).selling_d).format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
							append = append + "STILL AVAILABLE";
						}else {
							append = append + ((car)i).selling_d;
						}
						
						
						}
					 else{
						 //appends list model to display for vans
						 append = "license plate: "+ ((car)i).licence_plate + ", model: " + ((car)i).model+ ", type: " + ((car)i).car_type+
								 	", size: "+((van)i).size + ", colour: " +((car)i).colour+ ", mileage: " +
									((car)i).mileage+ ", accident history: " + ((car)i).accident_h
									+ ", transmission:  " + ((car)i).transmission+ ", price: " + ((car)i).price+ ", arrival date: " + 
									((car)i).arrival_d+ ", date sold: ";
							if ((((car)i).selling_d).format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
								append = append + "STILL AVAILABLE";
							}else {
								append = append + ((van)i).selling_d;
							}
							
							
							
						
					 }
				
				 model.add(count, append);
				 count++;
				}
				
				listSearch.setModel(model);
				//end of listbox display cars>>>>
			}
		});
		btnSearchBySeat.setBounds(31, 189, 401, 23);
		frmStaffSearch.getContentPane().add(btnSearchBySeat);
		
		JButton btnSearchVansBy = new JButton("Search vans by size");
		btnSearchVansBy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				searchVehiclelist.clear();
				
				
					for(Object i: login_window.Vehicles){
						if(((car)i).car_type.contentEquals("Van")) {
							if(((van)i).size.contains((String)comboBox.getSelectedItem())) {
								searchVehiclelist.add((car)i);
							}
						}
					}
				//start of listbox display cars>>>>
				DefaultListModel model = new DefaultListModel();
				int count = 0;
				
				model.removeAllElements();
				
				for(Object i: searchVehiclelist){
						String append = "";
					//format for accessing vehicles array
					if (!((car)i).car_type.contentEquals("Van")) {
						//appends list model to display for cars
							append = "license plate: "+ ((car)i).licence_plate + ", model: " + ((car)i).model+ ", type: " + ((car)i).car_type+", colour: " +((car)i).colour + ", mileage: " +
								((car)i).mileage+ ", accident history: " + ((car)i).accident_h
								+ ", transmission:  " + ((car)i).transmission+ ", price: " + ((car)i).price+ ", arrival date: " + 
								((car)i).arrival_d+ ", date sold: ";
						if ((((car)i).selling_d).format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
							append = append + "STILL AVAILABLE";
						}else {
							append = append + ((car)i).selling_d;
						}
						
						
						}
					 else{
						 //appends list model to display for vans
						 append = "license plate: "+ ((car)i).licence_plate + ", model: " + ((car)i).model+ ", type: " + ((car)i).car_type+
								 	", size: "+((van)i).size + ", colour: " +((car)i).colour+ ", mileage: " +
									((car)i).mileage+ ", accident history: " + ((car)i).accident_h
									+ ", transmission:  " + ((car)i).transmission+ ", price: " + ((car)i).price+ ", arrival date: " + 
									((car)i).arrival_d+ ", date sold: ";
							if ((((car)i).selling_d).format(DateTimeFormatter.ISO_LOCAL_DATE).contentEquals("0000-01-01")) {
								append = append + "STILL AVAILABLE";
							}else {
								append = append + ((van)i).selling_d;
							}
							
							
							
						
					 }
				
				 model.add(count, append);
				 count++;
				}
				
				listSearch.setModel(model);
				//end of listbox display cars>>>>
				
			}
		});
		btnSearchVansBy.setBounds(31, 312, 401, 23);
		frmStaffSearch.getContentPane().add(btnSearchVansBy);
			
		
		
		
	}
	
	
}
