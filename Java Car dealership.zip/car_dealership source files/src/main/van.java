package main;

import javax.swing.JOptionPane;

public class van extends car {
	
	public String size;

	van(String lp, String mo, String ct, String sz, String c, String mi, String ah, String t, String p, String ad, String sd) {
		super(lp, mo, ct, c, mi, ah, t, p, ad, sd);
		
		size = sz;
	}

}
