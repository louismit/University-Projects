package main;

public class user {
	
	public String username;
	public String type_id;
	public String password;
	
	user(String username, String password, String type_id) {
		this.username = username;
		this.type_id=type_id;
		this.password = password;
	}
	
	void loaduserUI(){ //loads user type ui
		user_search.main(null);
	}
	
}
