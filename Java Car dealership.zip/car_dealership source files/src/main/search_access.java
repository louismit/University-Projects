package main;

public enum search_access {
LIMITED,
ALL
}
