from tkinter import *
import tkinter.messagebox
import datetime


def returnBook(UserID):

    def DisplayBorrow(): #updates the users borrowed books in a list box
        currentLoans.delete(0,END)
        displayList = []
        data=open("database.txt","r")
        for x in data:
            xlist = x.split(",")
            xlist[3].strip('\n')
            for i in range(4):
                xlist[i] = xlist[i].strip()
            if int(xlist[3]) == UserID: #only displays if the current books database entry matches the userID
                displayList += [xlist]
        for i in displayList:
            currentLoans.insert(END,"Book: "+ i[1]+", ID: "+ i[0])
            
        data.close()

    def returnToLib():

        try:
            bookID = int(returnBox.get())
            book=[] #current database entry in list form
            lineToDelete = "" #variable for database entry to change
            bookString ="" #string version of book being handled
            data=open("database.txt","r") #reads database and finds entry to change
            for x in data:
                xlist = x.split(",")
                xlist[3].strip('\n')
                for i in range(4):
                    xlist[i] = xlist[i].strip()
                if bookID == int(xlist[0]) and UserID == int(xlist[3]):
                    lineToDelete = x
                    book = xlist
            data.close()
            data = open("database.txt","r") #prepares database for changing of values
            allData = data.readlines()
            data.close()
            book[3] = '0'
            data = open("database.txt","w")
            for i in allData: #changes user value in entry back to 0 meaning book has been returned
                if i!=lineToDelete:
                    data.write(i)
                elif i ==lineToDelete:
                    bookString = ','.join(book)
                    data.write(bookString +"\n")
            data.close()

            dataLog = open("logfile.txt","a") #logs the change made to the database in the Log file
            dataLog.write(bookString+','+str(datetime.datetime.now())+'\n')
            dataLog.close()
            DisplayBorrow()#re-displays the books loaned now that one has been returned
            returnBox.delete(0,END)
            tkinter.messagebox.showinfo("Book Return",str(book[1])+" has been returned")
        except:
            tkinter.messagebox.showerror("Error in Book ID","Please enter the ID of a book you have on loan.")
        

    returnGui = Tk()
    returnGui.title("Book Return")
    returnGui.geometry("700x200")
    returnGui.resizable(False,False) #fixes window size
    returnGui.configure(bg = '#aedb9f')
    Left = Frame(returnGui,bg = '#aedb9f')
    Right = Frame(returnGui,bg = '#aedb9f')
    Left.pack(side = LEFT)
    Right.pack()

    boxLabel = Label(Right, text = "List of Your Borrowed Books",bg = '#aedb9f')
    currentLoans = Listbox(Right, width = 50) #shows list of all borrowed books by user
    returnBox = Entry(Left,width = 50,)#input for id of book to return 
    returnLabel= Label(Left,text = "User: " + str(UserID)+ ". Enter Book ID to return book",bg = '#aedb9f')
    returnButton = Button(Left, text = "Return Book", width = 20,command=returnToLib)

    boxLabel.pack()
    returnLabel.grid(column = 0, row = 0,padx = 5,columnspan = 2)
    returnBox.grid(column = 0, row = 1,columnspan = 2,padx = 5, pady = 2)
    returnButton.grid(row = 4, columnspan = 2,pady = 10)
    currentLoans.pack(pady = 15)


    returnGui.after_idle(DisplayBorrow)
    returnGui.mainloop()
