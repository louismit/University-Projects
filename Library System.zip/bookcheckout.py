import datetime

def checkout(UserID, bookID):
    book=[] #current database entry in list form
    lineToDelete = "" #variable for database entry to change
    bookString ="" #string version of book being passed to funtion
    data=open("database.txt","r") #reads database and finds entry to change
    for x in data:
        xlist = x.split(",")
        xlist[3].strip('\n')
        for i in range(4):
            xlist[i] = xlist[i].strip()
        if bookID == int(xlist[0]):
            lineToDelete = x
            book = xlist
    data.close()
    data = open("database.txt","r") #prepares database for changing of values
    allData = data.readlines()
    data.close()
    book[3] = str(UserID)
    data = open("database.txt","w")
    for i in allData: #executes the nexesarry change of database values
        if i!=lineToDelete:
            data.write(i)
        elif i ==lineToDelete:
            bookString = ','.join(book)
            data.write(bookString +"\n")
    data.close()

    dataLog = open("logfile.txt","a") #logs the change made to the database in the Log file
    dataLog.write(bookString+','+str(datetime.datetime.now())+'\n')
    dataLog.close()
