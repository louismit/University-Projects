from tkinter import *
import bookcheckout


def search(UserID):

    def checkoutBook(): #checks out book (is only available when required criteria are met)
        if currentBook[3] == '0': # ensures book can only be checked out whilst it is not on loan
           bookcheckout.checkout(int(UserID), int(currentBook[0])) #sends the user ID and book ID to the checkout function
           bookOutput.insert(4,"")
           bookOutput.insert(3,"You have checked out this book")
           bookOutput.delete(4,END)

           
    def nameSearch(): #searches book database by book name
        bookOutput.delete(0,END)
        inp = searchBox.get()
        
        if inp =="":
            bookOutput.insert(END,"Enter a value to search")
        else:
            data=open("database.txt","r")
            for x in data: #runs through the book database and checks for a match with book name
                found = False
                xlist = x.split(",")
                xlist[3].strip('\n')
                for i in range(4):
                    xlist[i] = xlist[i].strip()
                if xlist[1] == inp:
                    found = True
                    global currentBook # creates global variable for current book
                    currentBook = xlist
                    bookOutput.insert(END,"Book: "+ inp)
                    bookOutput.insert(END,"Author: "+ xlist[2])
                    bookOutput.insert(END,"ID: " + xlist[0])
                    bookOutput.insert(END,"Found")
                    if int(xlist[3]) == 0: #checks availability of book and enables of disables checkout accordingly
                        bookOutput.insert(END,"Book available for loan")
                        checkoutButton.configure(state=NORMAL)
                        break
                    else:
                        bookOutput.insert(END,"Book is not available, on loan to USER: " + xlist[3])
                        checkoutButton.configure(state=DISABLED)
                        break
            if found == False:          #output if no book is found
                checkoutButton.configure(state=DISABLED)
                bookOutput.insert(END,"No book found under that name")
            data.close()
    

    def authorSearch(): #searches book database by Author Name
        bookOutput.delete(0,END)
        
        inp = searchBox.get()
        
        if inp =="":
            bookOutput.insert(END,"Enter a value to search")
        else:
            data=open("database.txt","r")
            entry = [] #stores a single database entry
            entryCount = 0 #counts how many books by this author are in the satabase
            found = False #indicates whether or not a book is found
            for x in data: #runs through the book database and checks for a match with author name
                xlist = x.split(",")
                xlist[3].strip('\n')
                for i in range(4):
                    xlist[i] = xlist[i].strip()
                if xlist[2] == inp:
                    entry = xlist
                    entryCount += 1
                    found = True
            xlist = entry
            global currentBook # creates global variable for current book
            currentBook = xlist
            if entryCount > 1: #if there are multiple books by the same author, the user must search by bookname
                bookOutput.insert(END, str(entryCount) + " books found by this author")
                bookOutput.insert(END,"Please search by Book name")
                checkoutButton.configure(state=DISABLED)
            else:
                if found == False:          #output if no book is found
                    checkoutButton.configure(state=DISABLED)
                    bookOutput.insert(END,"No book found by that Author")
                else:
                    bookOutput.insert(END,"Book: "+ xlist[1])
                    bookOutput.insert(END,"Author: "+ inp)
                    bookOutput.insert(END,"Book ID: " + xlist[0])
                    bookOutput.insert(END,"Found")
                    if int(xlist[3]) == 0: #checks availability of book and enables or disables checkout accordingly
                        bookOutput.insert(END,"Book available for loan")
                        checkoutButton.configure(state=NORMAL)
                        
                    else:
                        bookOutput.insert(END,"Book is not available, on loan to USER: " + xlist[3])
                        checkoutButton.configure(state=DISABLED)
            data.close()                 
            
                    
                    
   
    #below is formatting for the booksearch GUI
    searchGui = Tk()
    searchGui.title("Book Search")
    searchGui.geometry("700x200")
    searchGui.resizable(False,False) #fixes window size
    searchGui.configure(bg = '#aedb9f')
    Left = Frame(searchGui,bg = '#aedb9f')
    Right = Frame(searchGui,bg = '#aedb9f')
    Left.pack(side = LEFT)
    Right.pack()

    bookOutput = Listbox(Right, width = 50) #output for the searches
    searchBox = Entry(Left,width = 50,)#input for the searches
    searchLabel = Label(Left,text = "User: " + str(UserID)+ ", Enter Search Term",bg = '#aedb9f')
    nameButton = Button(Left,text = "Search by Book name",width = 20,command = nameSearch)
    authorButton = Button(Left, text = "Search by Author", width = 20,command = authorSearch)
    checkoutButton = Button(Left, text = "Checkout Book", width = 20, command = checkoutBook, state = DISABLED)

    searchLabel.grid(column = 0, row = 0,padx = 5,columnspan = 2)
    searchBox.grid(column = 0, row = 1,columnspan = 2,padx = 5, pady = 2)
    nameButton.grid(column = 0, row = 3, padx = 5, pady = 2)
    authorButton.grid(column = 1, row = 3, padx = 2)
    checkoutButton.grid(row = 4, columnspan = 2)
    bookOutput.pack(pady = 15)
    
    
    searchGui.mainloop()
