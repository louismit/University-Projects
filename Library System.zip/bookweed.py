import datetime
import tkinter.messagebox
from tkinter import *

def dateweed():
       
    def removebook(index): #removes a single book from the database as long as it isnt checked out
        forsakenEntry = "" #variable for database entry to be deleted
        removedEntry =[] #lest version of entry for deletion
        database = open("database.txt","r")
        for x in database:
            
            data = x.split(',')
            data[3].strip('\n')
            for i in range(4):
                data[i] = data[i].strip()   
            if (index == int(data[0])) and (int(data[3]) ==0): #ensures a book on loan is not deleted from database
                forsakenEntry = x
                removedEntry = data
        database.close()
        
        database = open("database.txt","r")
        allLines = database.readlines()
        database.close()


        database = open("database.txt","w")
        for i in allLines: #recompiles the database without the removed entry
            if i!=forsakenEntry:
                database.write(i)
            elif i ==forsakenEntry:
                bookOutput.insert(END,str(removedEntry[1],)+" removed")
                
        database.close()     
        
            
            
    def weed(): #removes books that have remained unused since the input date - will not remove books that are checked out
        try:
            bookOutput.delete(0,END)
            highestIndex = 0 #variable for the highest value for an indexed book
            entry = DateSearch.get()+' 00:00:00.000' #specifies the date before which book should be removed
            entryDateTime= datetime.datetime.strptime(entry, '%Y-%m-%d %H:%M:%S.%f')
            entryDate = entryDateTime.date()
            logData = open("logfile.txt","r")
            for current in logData: #this sets the highestIndex to determine how many times to loop through the log file when weeding
                currentList = current.split(',')
                if int(currentList[0])>highestIndex:
                    highestIndex = int(currentList[0]) #sets the variable which is how many times to loop through the log file
            logData.close()
            for currentIndex in range(1,highestIndex+1): #looks for each book index from min to max in the logfile
                highestDate = datetime.date(1, 1, 1) #variable for the most recent time a book has been viewed
                bookfound = False #indicates wheter a book of the ID of the current loop is found
                mostRecentEntry = [] #variable for the most recent enry of any given book
                logData = open("logfile.txt","r")
                for current in logData: #finds the most recent change to any book in the log
                    currentList = current.split(',')
                    if int(currentList[0]) == currentIndex:
                        bookfound=True
                        query = currentList[4].strip('\n') #datetime of the current entry 
                        query = query[:-3]
                        queryDateTime= datetime.datetime.strptime(query, '%Y-%m-%d %H:%M:%S.%f')
                        queryDate =queryDateTime.date()
                        if (queryDate > highestDate): #prevents books that are checked out from being deleted
                            highestDate = queryDate
                logData.close()

                if (bookfound == True) and (entryDate>highestDate): #if date entered is higher than most recent change to book, remove book
                    removebook(currentIndex)
        except:
            tkinter.messagebox.showerror("Entry out of Range","Please enter a date in the correct format")
        

        
    #below is the formatting of the Gui for the weeding interface
    WeedGui = Tk()
    WeedGui.title("Remove Unused Books From Database")
    WeedGui.geometry("700x200")
    WeedGui.resizable(False,False) #fixes window size
    WeedGui.configure(bg = '#aedb9f')
    Left = Frame(WeedGui,bg = '#aedb9f')
    Right = Frame(WeedGui,bg = '#aedb9f')
    Left.pack(side = LEFT)
    Right.pack()

    bookOutput = Listbox(Right, width = 50) #output for the searches
    DateSearch = Entry(Left,width = 50,)#input for the searches
    searchLabel = Label(Left,text = "Enter a date int the form YYYY-MM-DD\n (This will remove all books from the database \nthat have not been used since that date)",bg = '#aedb9f')
    weedButton = Button(Left,text = "Remove books",width = 20,command = weed)

    searchLabel.grid(column = 0, row = 0,padx = 5,columnspan = 2)
    DateSearch.grid(column = 0, row = 1,columnspan = 2,padx = 5, pady = 2)
    weedButton.grid(column = 0,columnspan = 2, row = 3, padx = 5, pady = 2)
    bookOutput.pack(pady = 15)
    
    WeedGui.mainloop()

