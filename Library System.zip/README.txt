Louis Mitchener Library System

-Database Format: 
 BookId,Bookname,Author,UserID (0 if book not checked out)

-Log Format: 
 BookId,Bookname,Author,UserID,TimeStamp

The log works by logging whenever any value is changed in the database
The log does not record removal (weeding) events - only book check outs and returns


Important-
All testing should be done via the GUI as each button is bound to the required functions.
If you wish to edit the database of logfile, ensure that the edits reflext the format of each file, any entries
of the wrong list size, or any empty lines anywhere in either file will cause errors


Test Data and Instructions:

-menu:
 Run the menu.py file to access the Library System
 Before any other function is available, the user must log on. this stores the user id, used by the other functions
 from here, you can choose from the three modules, search, return, and weed, or open the database or log, using the
 buttons on the interface.
 For testing: use the login value 7777

-booksearch:
 from the menu select Search for Books
 search by author:'J. K. Rowling' will return a request to search by book name due to multiple books.
 search by author:'Harper Lee' will return book information for To Kill a Mockingbird and will say the book is
                  available and will enable the checkout button.
 search by author:'F. Scott Fitzgerald' will return book information and will say the book is not available.
 search by Book Name:'1984' will return information on 1984 by George Orwell and will say it is available.

-checkout:
 Checkouts are done from the search page by first searching for a book then selecting checkout.
 first search for a book such as '1984', then select checkout. The database will update the entry for that book
 with your user id indicating it has been checked out, a log entry will also be made with a timestamp of the checkout.
 There will also be a message in the listbox indicating that the book has been checked out.
 Close the window when you are done checking out.

-bookreturn:
 From the menu page, select book Return Books
 This will display all the books currently due for return by the current user. if you have logged in as 7777 and
 checked out the book '1984', this book will be displayed on this page along with its BookID.
 In order to return a book, input the ID of the book into the entrybox on the screen, the ID is found on the list of
 books for return on the right hand side of the window, in the case of 1984, the ID will be 9.
 When a book is returned, the database value for user ID is set back to 0 for the book indicating it has been returned
 a log entry is made with a timestamp of the change to the database.

-bookweed:
 The bookweed page is accessed by pressing the Weed Out Books button on the menu page.
 On this page is an input box into which you can input a date in the form YYYY-MM-DD. When this is done, the program
 will search the log file for any book, which isnt currently checked out, that has not been accessed since the 
 entered date.
 Enter the date 2006-12-12 and two entries will be deleted harry potter and the chamber of secrets, and harry potter
 and the prisoner of askaban. this will be displayed in the listbox on the window, these books will also have been 
 deleted from the database.
 By entering any date in the future, all books except those that are currently on loan will be deleted.
 If this list exceeds the size of the Listbox, you can scroll down the listbox to see more entries
 
 
 
 