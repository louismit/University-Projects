from tkinter import *
import tkinter.messagebox
import subprocess
import booksearch
import bookreturn
import bookweed

def runWeed():
    bookweed.dateweed()
    
def runReturn():
    bookreturn.returnBook(UserID)
  
def runSearch():
    booksearch.search(UserID)

def logon(): #operates the logon function
    try: #ensures the UserID is of type Integer
        global UserID #login value for the user currently using the system
        inp = entryBox.get()
        attempt = int(inp)
        if 1000<=attempt<=9999: #checks if the user ID is a valid value
            UserID = attempt
            topLabel.configure(text = "Welcome User (ID "+inp+")")
            entryBox.delete(0,END)
            btnLogout.grid(padx = 50,column=0,row=1)#shows the log out button
            btnLogon.grid_forget()
            btnSearch.configure(width = 15, padx = 20,state=NORMAL)
            btnReturn.configure(width = 15, padx = 20,state=NORMAL)
            btnWeed.configure(width = 15, padx = 20,state=NORMAL)
            btnViewLog.configure(width = 15, padx = 20,state=NORMAL)
            btnOpenDatabase.configure(width = 15, padx = 20,state=NORMAL)
            entryBox.configure(state = DISABLED)
            
        else:
            tkinter.messagebox.showerror("Range Error","Please input a valid UserID between 1000 and 9999 inclusive")
    except:
        tkinter.messagebox.showerror("Type Error","Enter your UserID (must be a number between 1000 and 9999)") 

def logout(): #resets the program and resets the user ID
    UserID = 0
    btnLogon.configure(height = 1, width = 10)# shows the log on button
    btnLogon.grid(padx = 50,column = 3,row = 1)
    btnLogout.grid_forget()
    topLabel.configure(text = "Enter a User ID")
    btnSearch.configure(width = 15, padx = 20,state=DISABLED)
    btnReturn.configure(width = 15, padx = 20,state=DISABLED)
    btnWeed.configure(width = 15, padx = 20,state=DISABLED)
    btnViewLog.configure(width = 15, padx = 20,state=DISABLED)
    btnOpenDatabase.configure(width = 15, padx = 20,state=DISABLED)
    entryBox.configure(state=NORMAL)
    
    

def OpenLog(): #opens the log file
    subprocess.Popen(['notepad.exe', 'logfile.txt'])

def OpenDatabase():
    subprocess.Popen(['notepad.exe', 'database.txt'])


#all initial tkinter formatting for menu.py is listed below this point
root = Tk()
root.title("Library System Menu")
root.geometry("500x200")
root.resizable(False,False) #fixes window size
root.configure(bg = '#aedb9f')


#seperates the window into two halves for arranging buttons
Top = Frame(root)
Bottom = Frame(root)
Top.pack()
Bottom.pack(side=BOTTOM)
Top.configure(bg = '#aedb9f')
Bottom.configure(bg = '#aedb9f')

entryBox = Entry(Top)#box for all inputs in the program
topLabel = Label(Top,text = "Enter a User ID")#the label above the input box showing if somebody is logged in
padLabelLeft = Label(Top) #acts as padding for left column
padLabelRight = Label(Top)#acts as padding for right column
padLabelTop = Label(Bottom)
padLabelBottom = Label(Bottom)
btnLogout = Button(Top, text = "Logout",command = logout)#creates a logout button
btnLogon = Button(Top, text = "Logon",command = logon)#creates a logon button
btnSearch = Button(Bottom, text = "Search for Books", command = runSearch)#calls the booksearch.py file
btnReturn = Button(Bottom, text = "Return Books",command = runReturn) #calls the bookreturn.py file
btnWeed = Button(Bottom, text = "Weed out Books", command =runWeed)#calls the bookweed.py file
btnViewLog = Button(Bottom, text ="View Book Log", command = OpenLog)#opens log txt file
btnOpenDatabase = Button(Bottom, text = "View Book Database", command = OpenDatabase)#opens book database txt file


#defines all initial formatting for the user interface
padLabelLeft.grid(padx = 50,column=0,row = 0)
padLabelLeft.configure(height = 1,width = 10,bg = '#aedb9f')
padLabelRight.grid(padx = 50,column = 3,row =0)
padLabelRight.configure(height = 1,width = 10,bg = '#aedb9f')
padLabelTop.grid(ipadx = 60, column = 0,row =2)
padLabelTop.configure(height = 1,width = 15,bg = '#aedb9f')
padLabelBottom.grid(column = 0,row =3)
padLabelBottom.configure(height = 1,width = 15,bg = '#aedb9f')

btnLogon.configure(height = 1, width = 10)
btnLogout.configure(height = 1,width = 10) 
btnLogon.grid(padx = 50,column = 3,row = 1)
entryBox.grid(row=1,pady = 3,column = 1)
topLabel.configure(bg = '#aedb9f')
topLabel.grid(row=0,pady = 1,column = 1)
btnSearch.configure(width = 15, padx = 20,state=DISABLED)
btnReturn.configure(width = 15, padx = 20,state=DISABLED)
btnWeed.configure(width = 15, padx = 20, state=DISABLED)
btnViewLog.configure(width = 15, padx = 20,state=DISABLED)
btnOpenDatabase.configure(width = 15, padx = 20,state=DISABLED)
btnSearch.grid(column=1,row=0)
btnReturn.grid(column=1,row = 1)
btnWeed.grid(column=1,row = 2)
btnViewLog.grid(column=0,row=0)
btnOpenDatabase.grid(column=0,row=1)

root.mainloop()
